# Player Nametag Tweaks

This mod increases player nametag render distance and makes so nametags are scaled down if far away (can be turned off).

## Configuration
1. Render distance (default = *64*)
1. Scale down nametag over distance (default = *True*)

![Screenshot](https://github.com/michalczemierowski/valheim-PlayerNametagTweaks/blob/master/screenshots/ss.png?raw=true "a title")