# Player Nametag Tweaks v1.0.1

This mod increases player nametag render distance and makes so nametags are scaled down if far away (can be turned off).

## Configuration
1. Render distance (default = *64*)
2. Scale down nametag over distance (default = *True*)
3. Show player nametags when they're sneaking/crouching (default = *True*)

![Screenshot](https://github.com/michalczemierowski/valheim-PlayerNametagTweaks/blob/master/screenshots/ss.png?raw=true "a title")